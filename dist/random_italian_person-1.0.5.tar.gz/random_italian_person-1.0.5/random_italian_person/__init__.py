from .random_italian_person import RandomItalianPerson

__all__ = [
    "RandomItalianPerson"
]