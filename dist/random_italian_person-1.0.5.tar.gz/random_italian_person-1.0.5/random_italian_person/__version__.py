"""Current version of package random_italian_person"""
__version__ = "1.0.5"